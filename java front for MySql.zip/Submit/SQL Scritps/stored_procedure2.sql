#The second stored procedure I made

DELIMITER //

CREATE PROCEDURE RegisterAthleteForTrackEvent
(
    IN p_athleteID INT,
    IN p_eventName VARCHAR(100),
    IN p_eventDate DATE
)
BEGIN
    DECLARE v_eventID INT;
    DECLARE v_sportID INT;
    DECLARE v_participationCount INT;
    
    
    -- Check if the event is already inserted, if not, insert it
    SELECT eventID, sportID INTO v_eventID, v_sportID FROM Event WHERE eventName = p_eventName AND date = p_eventDate;
    
    IF v_eventID IS NULL THEN
        -- Event doesn't exist
        -- We will only add Track sport events
        INSERT INTO Event (eventName, sportID, date) VALUES (p_eventName, 1, p_eventDate);
        SET v_eventID = LAST_INSERT_ID();
    END IF;
    
    -- Check if the athlete is already registered for this event
    SELECT COUNT(*) INTO v_participationCount
    FROM Participation
    WHERE athleteID = p_athleteID AND eventID = v_eventID;
    
    IF v_participationCount > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Athlete is already registered for this event';
    ELSE
        
            -- Register the athlete for the event
            INSERT INTO Participation (athleteID, eventID, ranking)
            VALUES (p_athleteID, v_eventID, 0);  -- Initial ranking set to 0
            
            SELECT CONCAT('Athlete ', p_athleteID, ' successfully registered for event ', p_eventName) AS Result;
        
    END IF;
END //

DELIMITER ;
