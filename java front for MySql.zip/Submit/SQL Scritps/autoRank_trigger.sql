#The first trigger for automatically ranking when medal is given

DELIMITER //

CREATE TRIGGER update_ranking_after_medal
AFTER UPDATE ON Participation
FOR EACH ROW
BEGIN
    IF NEW.medalID IS NOT NULL AND OLD.medalID IS NULL THEN
        -- A medal has been awarded, update the ranking
        SET @medal_type = (SELECT medalType FROM Medal WHERE medalID = NEW.medalID);
        
        IF @medal_type = 'Gold' THEN
            UPDATE Participation SET ranking = 1 WHERE eventID = NEW.eventID AND athleteID = NEW.athleteID;
        ELSEIF @medal_type = 'Silver' THEN
            UPDATE Participation SET ranking = 2 WHERE eventID = NEW.eventID AND athleteID = NEW.athleteID;
        ELSEIF @medal_type = 'Bronze' THEN
            UPDATE Participation SET ranking = 3 WHERE eventID = NEW.eventID AND athleteID = NEW.athleteID;
        END IF;
    END IF;
END //

DELIMITER ;

--Try

-- Inserting values into Medal table

INSERT INTO Athlete (firstName, lastName, countryID)
VALUES
('Naruto', 'Uzumaki', 3);

INSERT INTO Medal (medalType, eventID)
VALUES
('Gold', 26);

UPDATE Participation 
SET medalID = 54 
WHERE athleteID = 19 AND eventID = 26;