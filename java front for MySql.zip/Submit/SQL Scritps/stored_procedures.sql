#The first stored procedures I made

DELIMITER //

CREATE PROCEDURE UpdateMedalCounts(IN p_month INT, IN p_year INT)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE v_countryID INT;
    DECLARE v_gold INT;
    DECLARE v_silver INT;
    DECLARE v_bronze INT;
    
    DECLARE country_cursor CURSOR FOR 
        SELECT DISTINCT c.countryID 
        FROM Country c
        JOIN Athlete a ON c.countryID = a.countryID
        JOIN Participation p ON a.athleteID = p.athleteID
        JOIN Event e ON p.eventID = e.eventID
        WHERE MONTH(e.date) = p_month AND YEAR(e.date) = p_year;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    -- Check input
    IF p_month < 6 OR p_month > 9 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Invalid month for 2024 Olymipcs. Please enter a number between 6 and 9.';
    END IF;

    -- Create temp table to store the results
    CREATE TEMPORARY TABLE IF NOT EXISTS TempMedalCounts 
    (
        countryID INT,
        gold_count INT,
        silver_count INT,
        bronze_count INT
    );
    
    OPEN country_cursor;
    
    read_loop: LOOP
        FETCH country_cursor INTO v_countryID;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        -- Count gold medals
        SELECT COUNT(*) INTO v_gold
        FROM Athlete a
        JOIN Participation p ON a.athleteID = p.athleteID
        JOIN Medal m ON p.medalID = m.medalID
        JOIN Event e ON p.eventID = e.eventID
        WHERE a.countryID = v_countryID AND m.medalType = 'Gold' 
            AND MONTH(e.date) = p_month AND YEAR(e.date) = p_year;
        
        -- Count silver medals
        SELECT COUNT(*) INTO v_silver
        FROM Athlete a
        JOIN Participation p ON a.athleteID = p.athleteID
        JOIN Medal m ON p.medalID = m.medalID
        JOIN Event e ON p.eventID = e.eventID
        WHERE a.countryID = v_countryID AND m.medalType = 'Silver' 
            AND MONTH(e.date) = p_month AND YEAR(e.date) = p_year;
        
        -- Count bronze medals
        SELECT COUNT(*) INTO v_bronze
        FROM Athlete a
        JOIN Participation p ON a.athleteID = p.athleteID
        JOIN Medal m ON p.medalID = m.medalID
        JOIN Event e ON p.eventID = e.eventID
        WHERE a.countryID = v_countryID AND m.medalType = 'Bronze' 
            AND MONTH(e.date) = p_month AND YEAR(e.date) = p_year;
        
        -- Insert results into temporary table
        INSERT INTO TempMedalCounts (countryID, gold_count, silver_count, bronze_count)
        VALUES (v_countryID, v_gold, v_silver, v_bronze);
    END LOOP;
    
    CLOSE country_cursor;
    
    -- Show results
    SELECT c.countryName, t.gold_count, t.silver_count, t.bronze_count, 
           (t.gold_count + t.silver_count + t.bronze_count) AS total_medals
    FROM TempMedalCounts t
    JOIN Country c ON t.countryID = c.countryID
    ORDER BY total_medals DESC, t.gold_count DESC, t.silver_count DESC, t.bronze_count DESC;
    
    -- remove the table after done
    DROP TEMPORARY TABLE IF EXISTS TempMedalCounts;
END //

DELIMITER ;
