-- Inserting values to the tables

INSERT INTO Country (countryName)
VALUES
('United States'),
('China'),
('Japan'),
('Russia'),
('Germany');

INSERT INTO Country (countryName)
VALUES
('Jamaica'),
('Australia'),
('Brazil'),
('Italy'),
('South Korea'),
('France'),
('Kenya'),
('Mexico'),
('India');

-- Inserting values into Sport table

INSERT INTO Sport (sportName)
VALUES
('Track'),
('Swimming'),
('Gymnastics'),
('Weightlifting'),
('Boxing'),
('Wrestling'),
('Shooting'),
('Basketball'),
('Volleyball'),
('Football'),
('Handball'),
('Table tennis'),
('Badminton'),
('Tennis');

--Inserting values into Athlete table

INSERT INTO Athlete (firstName, lastName, countryID)
VALUES
('Usain', 'Bolt', 6),          
('Ian', 'Thorpe', 7),           
('Arthur', 'Zanetti', 8),       
('Naim', 'Suleymanoglu', 4),    
('Muhammad', 'Ali', 1),         
('Alexander', 'Karelin', 4),    
('Jin', 'Jong-oh', 10),          
('Michael', 'Jordan', 1),       
('Giba', 'Souza', 8),           
('Marta', 'Vieira', 8),         
('Nikola', 'Karabatic', 11),     
('Ma', 'Long', 2),              
('P. V.', 'Sindhu', 14),        
('Roger', 'Federer', 11);       


-- Inserting values into Event table

INSERT INTO Event (eventName, sportID, date)
VALUES
('100-meter dash', 1, '2024-07-23'),                  
('Freestyle Swimming', 2, '2024-07-24'),              
('Artistic Gymnastics', 3, '2024-07-25'),             
('Clean and Jerk', 4, '2024-07-26'),                  
('Heavyweight Boxing', 5, '2024-07-27'),              
('Greco-Roman Wrestling', 6, '2024-07-28'),           
('Pistol Shooting', 7, '2024-07-29'),                 
('Mens Basketball Final', 8, '2024-07-30'),         
('Mens Volleyball Final', 9, '2024-07-31'),         
('Womens Football Final', 10, '2024-08-01'),        
('Mens Handball Final', 11, '2024-08-02'),          
('Table Tennis Singles', 12, '2024-08-03'),           
('Badminton Singles', 13, '2024-08-04'),              
('Mens Tennis Final', 14, '2024-08-05');


-- Inserting values into Medal table

INSERT INTO Medal (medalType, eventID)
VALUES
('Gold', 1), ('Silver', 1), ('Bronze', 1),         
('Gold', 2), ('Silver', 2), ('Bronze', 2),         
('Gold', 3), ('Silver', 3), ('Bronze', 3),         
('Gold', 4), ('Silver', 4), ('Bronze', 4),         
('Gold', 5), ('Silver', 5), ('Bronze', 5),         
('Gold', 6), ('Silver', 6), ('Bronze', 6),         
('Gold', 7), ('Silver', 7), ('Bronze', 7),         
('Gold', 8), ('Silver', 8), ('Bronze', 8),         
('Gold', 9), ('Silver', 9), ('Bronze', 9),         
('Gold', 10), ('Silver', 10), ('Bronze', 10),      
('Gold', 11), ('Silver', 11), ('Bronze', 11),      
('Gold', 12), ('Silver', 12), ('Bronze', 12),      
('Gold', 13), ('Silver', 13), ('Bronze', 13),      
('Gold', 14), ('Silver', 14), ('Bronze', 14);      

--Inserting values into Participation table

INSERT INTO Participation (athleteID, eventID, ranking, medalID)
VALUES
(1, 1, 1, 1),     
(2, 2, 1, 4),     
(3, 3, 1, 7),     
(4, 4, 1, 10),    
(5, 5, 1, 13),    
(6, 6, 1, 16),    
(7, 7, 1, 19),    
(8, 8, 1, 22),    
(9, 9, 1, 25),    
(10, 10, 1, 28),  
(11, 11, 1, 31),  
(12, 12, 1, 34),  
(13, 13, 1, 37),
(14, 14, 1, 40);

--new
INSERT INTO Participation (athleteID, eventID, ranking, medalID)
VALUES
(17, 1, 1, 2),     
(18, 2, 1, 5),     
(19, 3, 1, 8),     
(20, 4, 1, 11),    
(21, 5, 1, 14),    
(22, 6, 1, 17),    
(23, 7, 1, 20),    
(24, 8, 1, 23),    
(25, 9, 1, 26),    
(26, 10, 1, 29);

--new
INSERT INTO Participation (athleteID, eventID, ranking, medalID)
VALUES
(27, 1, 3, 3),     
(28, 2, 3, 6),     
(29, 3, 3, 9),     
(30, 4, 3, 12),    
(31, 5, 3, 15),    
(32, 6, 3, 18),    
(33, 7, 3, 21),    
(34, 8, 3, 24),    
(35, 9, 3, 27),    
(36, 10, 3, 28);


--UPDATE
UPDATE Participation
SET ranking = 2
WHERE athleteID IN (17, 18, 19,20,21,22,23,24,25,26);






