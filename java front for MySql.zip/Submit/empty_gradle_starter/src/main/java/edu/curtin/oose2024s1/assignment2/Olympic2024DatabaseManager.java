package edu.curtin.oose2024s1.assignment2;

/**
 * Use this code to get started on Assignment 2. You are free to modify or replace this file as
 * needed (to fulfil the assignment requirements, of course).
 */
import java.sql.*;
import java.util.Scanner;


public class Olympic2024DatabaseManager 
{
    
    private static final String URL = "jdbc:mysql://localhost:3306/Olympic_2024?serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "new_password";

    private static Connection connection;
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) 
    {
        try 
        {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Connected to the Olympic_2024 database.");

            while (true) 
            {
                printMenu();
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) 
                {
                    case 1:
                        countAthletesByCountry();
                        break;
                    case 2:
                        findEventsByDate();
                        break;
                    case 3:
                        getAthletesMedalWinners();
                        break;
                    case 4:
                        countGoldMedalsByCountry();
                        break;
                    case 5:
                        findTopRankedAthletes();
                        break;
                    case 6:
                        findAthletesByLastName();
                        break;
                    case 7:
                        getTotalMedalsByEvent();
                        break;
                    case 8:
                        findCountryWithMostGoldMedals();
                        break;
                    case 9:
                        insertData();
                        break;
                    case 10:
                        updateData();
                        break;
                    case 11:
                        deleteData();
                        break;
                    case 0:
                        System.out.println("Exiting program.");
                        connection.close();
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }
    }

    private static void printMenu() 
    {
        System.out.println("\n--- Olympic 2024 Database Manager ---");
        System.out.println("1. Count Athletes by Country");
        System.out.println("2. Find Events by Date");
        System.out.println("3. Get Athletes Who Won a Medal");
        System.out.println("4. Count Gold Medals by Country");
        System.out.println("5. Find Top 3 Ranked Athletes in 100-meter dash");
        System.out.println("6. Find Athletes with Last Names Starting with 'B'");
        System.out.println("7. Get Total Medals by Event");
        System.out.println("8. Find Country with Most Gold Medals");
        System.out.println("9. Insert Data");
        System.out.println("10. Update Data");
        System.out.println("11. Delete Data");
        System.out.println("0. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void countAthletesByCountry() 
    {
        String query = "SELECT c.countryName, COUNT(a.athleteID) AS athlete_count " +
                       "FROM Country c " +
                       "JOIN Athlete a ON c.countryID = a.countryID " +
                       "GROUP BY c.countryID, c.countryName " +
                       "ORDER BY athlete_count DESC";
        executeQuery(query);
    }

    private static void findEventsByDate() 
    {
        System.out.print("Enter date (YYYY-MM-DD): ");
        String date = scanner.nextLine();
        String query = "SELECT e.eventName, s.sportName " +
                       "FROM Event e " +
                       "JOIN Sport s ON e.sportID = s.sportID " +
                       "WHERE e.date = '" + date + "'";
        executeQuery(query);
    }

    private static void getAthletesMedalWinners() 
    {
        String query = "SELECT CONCAT(a.firstName, ' ', a.lastName) AS athleteName, e.eventName, m.medalType " +
                       "FROM Athlete a " +
                       "JOIN Participation p ON a.athleteID = p.athleteID " +
                       "JOIN Medal m ON p.medalID = m.medalID " +
                       "JOIN Event e ON p.eventID = e.eventID " +
                       "WHERE m.medalType IS NOT NULL " +
                       "ORDER BY m.medalType";
        executeQuery(query);
    }

    private static void countGoldMedalsByCountry() 
    {
        String query = "SELECT c.countryName, COUNT(*) AS gold_medal_count " +
                       "FROM Country c " +
                       "JOIN Athlete a ON c.countryID = a.countryID " +
                       "JOIN Participation p ON a.athleteID = p.athleteID " +
                       "JOIN Medal m ON p.medalID = m.medalID " +
                       "WHERE m.medalType = 'Gold' " +
                       "GROUP BY c.countryID, c.countryName " +
                       "ORDER BY gold_medal_count DESC";
        executeQuery(query);
    }

    private static void findTopRankedAthletes() 
    {
        String query = "SELECT CONCAT(a.firstName, ' ', a.lastName) AS athleteName, p.ranking " +
                       "FROM Athlete a " +
                       "JOIN Participation p ON a.athleteID = p.athleteID " +
                       "JOIN Event e ON p.eventID = e.eventID " +
                       "WHERE e.eventName = '100-meter dash' " +
                       "ORDER BY p.ranking ASC LIMIT 3";
        executeQuery(query);
    }

    private static void findAthletesByLastName() 
    {
        String query = "SELECT firstName, lastName, c.countryName " +
                       "FROM Athlete a " +
                       "JOIN Country c ON a.countryID = c.countryID " +
                       "WHERE lastName LIKE 'B%' " +
                       "ORDER BY lastName, firstName";
        executeQuery(query);
    }

    private static void getTotalMedalsByEvent() 
    {
        String query = "SELECT e.eventName, s.sportName, COUNT(p.medalID) AS medal_count " +
                       "FROM Event e " +
                       "JOIN Sport s ON e.sportID = s.sportID " +
                       "LEFT JOIN Participation p ON e.eventID = p.eventID AND p.medalID IS NOT NULL " +
                       "GROUP BY e.eventID, e.eventName, s.sportName " +
                       "ORDER BY medal_count DESC";
        executeQuery(query);
    }

    private static void findCountryWithMostGoldMedals() 
    {
        String query = "SELECT c.countryName, COUNT(*) AS gold_medal_count " +
                       "FROM Country c " +
                       "JOIN Athlete a ON c.countryID = a.countryID " +
                       "JOIN Participation p ON a.athleteID = p.athleteID " +
                       "JOIN Medal m ON p.medalID = m.medalID " +
                       "JOIN Event e ON p.eventID = e.eventID " +
                       "WHERE m.medalType = 'Gold' " +
                       "GROUP BY c.countryID, c.countryName " +
                       "ORDER BY gold_medal_count DESC LIMIT 1";
        executeQuery(query);
    }

    private static void executeQuery(String query) 
    {
        try (Statement stmt = connection.createStatement();ResultSet rs = stmt.executeQuery(query)) 
        {

            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();

            
            for (int i = 1; i <= columnCount; i++) 
            {
                System.out.print(metaData.getColumnName(i) + "\t");
            }
            System.out.println();

        
            while (rs.next()) 
            {
                for (int i = 1; i <= columnCount; i++) 
                {
                    System.out.print(rs.getString(i) + "\t");
                }
                System.out.println();
            }
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }
    }

    private static void insertData() 
    {
        System.out.println("Select a table to insert data into:");
        System.out.println("1. Athlete");
        System.out.println("2. Country");
        System.out.println("3. Sport");
        System.out.println("4. Event");
        System.out.println("5. Medal");
        System.out.println("6. Participation");
        int choice = scanner.nextInt();
        scanner.nextLine(); 

        String query = "";
        switch (choice) 
        {
            case 1:
                query = "INSERT INTO Athlete (firstName, lastName, countryID) VALUES (?, ?, ?)";
                break;
            case 2:
                query = "INSERT INTO Country (countryName) VALUES (?)";
                break;
            case 3:
                query = "INSERT INTO Sport (sportName) VALUES (?)";
                break;
            case 4:
                query = "INSERT INTO Event (eventName, sportID, date) VALUES (?, ?, ?)";
                break;
            case 5:
                query = "INSERT INTO Medal (medalType, eventID) VALUES (?, ?)";
                break;
            case 6:
                query = "INSERT INTO Participation (athleteID, eventID, ranking, medalID) VALUES (?, ?, ?, ?)";
                break;
            default:
                System.out.println("Invalid choice.");
                return;
        }

        try (PreparedStatement pstmt = connection.prepareStatement(query)) 
        {
            
            for (int i = 1; i <= pstmt.getParameterMetaData().getParameterCount(); i++) 
            {
                System.out.print("Enter value for parameter " + i + ": ");
                String value = scanner.nextLine();
                pstmt.setString(i, value);
            }

            int rowsAffected = pstmt.executeUpdate();
            System.out.println(rowsAffected + " row(s) inserted.");
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }
    }

    private static void updateData() 
    {
        System.out.println("Select a table to update data:");
        System.out.println("1. Athlete");
        System.out.println("2. Country");
        System.out.println("3. Sport");
        System.out.println("4. Event");
        System.out.println("5. Medal");
        System.out.println("6. Participation");
        int choice = scanner.nextInt();
        scanner.nextLine(); 

        String tableName = "";
        String idColumnName = "";
        switch (choice) 
        {
            case 1:
                tableName = "Athlete";
                idColumnName = "athleteID";
                break;
            case 2:
                tableName = "Country";
                idColumnName = "countryID";
                break;
            case 3:
                tableName = "Sport";
                idColumnName = "sportID";
                break;
            case 4:
                tableName = "Event";
                idColumnName = "eventID";
                break;
            case 5:
                tableName = "Medal";
                idColumnName = "medalID";
                break;
            case 6:
                tableName = "Participation";
                idColumnName = "athleteID"; 
                break;
            default:
                System.out.println("Invalid choice.");
                return;
        }

        System.out.print("Enter " + idColumnName + " to update: ");
        int id = scanner.nextInt();
        scanner.nextLine(); 

        System.out.print("Enter column name to update: ");
        String columnName = scanner.nextLine();

        System.out.print("Enter new value: ");
        String newValue = scanner.nextLine();

        String query = "UPDATE " + tableName + " SET " + columnName + " = ? WHERE " + idColumnName + " = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) 
        {
            pstmt.setString(1, newValue);
            pstmt.setInt(2, id);

            int rowsAffected = pstmt.executeUpdate();
            System.out.println(rowsAffected + " row(s) updated.");
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }
    }

    private static void deleteData() 
    {
        System.out.println("Select a table to delete data from:");
        System.out.println("1. Athlete");
        System.out.println("2. Country");
        System.out.println("3. Sport");
        System.out.println("4. Event");
        System.out.println("5. Medal");
        System.out.println("6. Participation");
        int choice = scanner.nextInt();
        scanner.nextLine();

        String tableName = "";
        String idColumnName = "";
        switch (choice) 
        {
            case 1:
                tableName = "Athlete";
                idColumnName = "athleteID";
                break;
            case 2:
                tableName = "Country";
                idColumnName = "countryID";
                break;
            case 3:
                tableName = "Sport";
                idColumnName = "sportID";
                break;
            case 4:
                tableName = "Event";
                idColumnName = "eventID";
                break;
            case 5:
                tableName = "Medal";
                idColumnName = "medalID";
                break;
            case 6:
                tableName = "Participation";
                idColumnName = "athleteID"; 
                break;
            default:
                System.out.println("Invalid choice.");
                return;
        }

        System.out.print("Enter " + idColumnName + " to delete: ");
        int id = scanner.nextInt();
        scanner.nextLine(); 

        String query = "DELETE FROM " + tableName + " WHERE " + idColumnName + " = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) 
        {
            pstmt.setInt(1, id);

            int rowsAffected = pstmt.executeUpdate();
            System.out.println(rowsAffected + " row(s) deleted.");
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }
    }
}
