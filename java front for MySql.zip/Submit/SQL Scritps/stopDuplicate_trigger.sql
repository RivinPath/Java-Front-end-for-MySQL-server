#This trigger wont let medals that were already inserted to inserted again

DELIMITER //

CREATE TRIGGER prevent_duplicate_medals
BEFORE INSERT ON Medal
FOR EACH ROW
BEGIN
    DECLARE medal_count INT;
    
    SELECT COUNT(*) INTO medal_count
    FROM Medal
    WHERE eventID = NEW.eventID AND medalType = NEW.medalType;
    
    IF medal_count > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Duplicate medal type for this event';
    END IF;
END //

DELIMITER ;

--try
INSERT INTO Medal (medalType, eventID) VALUES ('Gold', 26);
