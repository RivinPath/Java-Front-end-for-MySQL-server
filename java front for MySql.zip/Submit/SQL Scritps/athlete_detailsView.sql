#A complex view that joins athlete and country table to show full name and country name of an athlete

CREATE VIEW AthleteCountryView AS
SELECT
    CONCAT(a.firstName, ' ', a.lastName) AS athleteName,
    c.countryName
FROM
    Athlete a
JOIN
    Country c ON a.countryID = c.countryID;

    --try
    SELECT * FROM AthleteCountryView;
