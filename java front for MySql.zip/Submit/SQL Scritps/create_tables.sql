-- Table creation

-- Create Athlete Table
CREATE TABLE Athlete (
    athleteID INT AUTO_INCREMENT PRIMARY KEY,
    firstName VARCHAR(50) NOT NULL,
    lastName VARCHAR(50) NOT NULL,
    countryID INT NOT NULL
);

-- Create Country Table
CREATE TABLE Country (
    countryID INT AUTO_INCREMENT PRIMARY KEY,
    countryName VARCHAR(100) NOT NULL
);

-- Create Sport Table
CREATE TABLE Sport (
    sportID INT AUTO_INCREMENT PRIMARY KEY,
    sportName VARCHAR(100) NOT NULL
);

-- Create Event Table
CREATE TABLE Event (
    eventID INT AUTO_INCREMENT PRIMARY KEY,
    eventName VARCHAR(100) NOT NULL,
    sportID INT NOT NULL,
    date DATE NOT NULL,
    FOREIGN KEY (sportID) REFERENCES Sport(sportID)
);

-- Create Medal Table
CREATE TABLE Medal (
    medalID INT AUTO_INCREMENT PRIMARY KEY,
    medalType VARCHAR(6) NOT NULL,
    eventID INT NOT NULL,
    FOREIGN KEY (eventID) REFERENCES Event(eventID)
);

-- Create Participation Table
CREATE TABLE Participation (
    athleteID INT NOT NULL,
    eventID INT NOT NULL,
    ranking INT NOT NULL,
    medalID INT,
    PRIMARY KEY (athleteID, eventID),
    FOREIGN KEY (athleteID) REFERENCES Athlete(athleteID),
    FOREIGN KEY (eventID) REFERENCES Event(eventID),
    FOREIGN KEY (medalID) REFERENCES Medal(medalID)
);

